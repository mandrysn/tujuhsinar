<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
    <title>Halaman Login | Tujuh Sinar</title>
    <!-- Css Files -->
    <link href="css/root.css" rel="stylesheet">
    <style type="text/css">
        body {
            background: #F5F5F5;
        }
    </style>
</head>
<body>
    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>
                <h1 class="logo-name">TS</h1>
            </div>
            <h3>Selamat datang di Tujuh Sinar</h3>
            <p>Silahkan login terlebih dahulu.</p>
            <form class="m-t" action="<?php echo e(route('login')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <input name="username" type="text" class="form-control" placeholder="Username" value="<?php echo e(old('username')); ?>" required="">
                </div>
                <div class="form-group">
                    <input name="password" type="password" class="form-control" placeholder="Password" required="">
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">Login</button>
                <br>
                
            </form>
            <p class="m-t"> <small>GreenNusa Computindo &copy; 2017</small> </p>
        </div>
    </div>
</body>
</html>