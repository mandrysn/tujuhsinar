<?php $__env->startSection('title', 'Pembelian Down Payment'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-padding animated fadeInRight"> 
        <div class="row"> 
            <!-- Start Panel -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-title">
                        <form class="form-horizontal"  method="post" action="<?php echo e(route('laporan.cetak.invoice')); ?>">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="periode" value="<?php echo e($periode); ?>" />
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Cetak</button>
                                    <a href="<?php echo e(route('laporan.transaksi')); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Kembali</a>
                                </div>
                        </form>
                    </div>
                    <div class="panel-body table-responsive">
    
                        <table id="example0" class="table display">
                            <thead>
                                <tr>
                                        <th>No</th>
                                        <th>No Order</th>
                                        <th>Deadline</th>
                                        <th>Costumer</th>
                                        <th >Bahan</th>
                                        <th >Estimasi</th>
                                        <th >Qty</th>
                                        <th>Keterangan</th>
                                            </tr>
                            </thead>
                            <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>'<?php echo e($datas->orderkerja->order); ?></td>
                                        <td><?php echo e(Helper::tanggalId($datas->deadline)); ?></td>
                                        <td><?php echo e($datas->orderkerja->pelanggan->nama); ?></td>
                                        <td><?php echo e(is_null($datas->barang_id) ? '-' : $datas->barang->nm_barang); ?></td>
                                        <td><?php echo e(number_format($datas->harga)); ?></td>
                                        <td><?php echo e($datas->qty); ?></td>
                                        <td><?php echo $datas->keterangan_sub; ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                            </tbody>
                <tfoot>

                </tfoot>
    </table>
                    </div>
                </div>
            </div>
            <!-- End Panel --> 
        </div>
        <!-- End Row --> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>