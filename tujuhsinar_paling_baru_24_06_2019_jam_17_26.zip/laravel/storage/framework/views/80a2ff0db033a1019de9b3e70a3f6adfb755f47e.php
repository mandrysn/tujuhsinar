<!-- Start Modal Code -->
<!-- Link -->
<!-- Modal -->
<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="modal fade bs-example" id="edit-<?php echo e($tampil->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Ukuran Bahan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-12">
        		    <form method="post" action="<?php echo e(route('ukuran-bahan.update', $tampil->id)); ?>">
        			<?php echo csrf_field(); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="col-md-12 col-lg-12">
                        <div class="form-group">
                            <label for="select2" class="form-label">Tipe Produk</label>
                            <select class="form-control" name="produk_id" id="edit_id" required>
                                <option disabled="">-- Pilih Tipe Produk --</option>
                                <option value="1" <?php echo e($tampil->produk_id == 1 ? "selected" : ""); ?>>Outdoor</option>
                                <option value="2" <?php echo e($tampil->produk_id == 2 ? "selected" : ""); ?>>Indoor</option>
                                <option value="3" <?php echo e($tampil->produk_id == 3 ? "selected" : ""); ?>>Merchant</option>
                                <option value="4" <?php echo e($tampil->produk_id == 4 ? "selected" : ""); ?>>Print A3</option>
                                <option value="5" <?php echo e($tampil->produk_id == 5 ? "selected" : ""); ?>>Costum</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group">
                            <label for="select2" class="form-label">Bahan</label>
                           <select class="form-control selectpicker" multiple="" name="barang_id[]" id="bahan" required>
                                <option disabled>-- Pilih Bahan --</option>
                                
                                <?php $__currentLoopData = $bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                $h = "";
                                  foreach ($tampil->detail as $d) {
                                        if($d->barang_id == $data->id){
                                            $h = "selected";
                                        }
                                    }
                                    
                                    
                                 ?>
                                <option value="<?php echo e($data->id); ?>" <?php echo e($h); ?>><?php echo e($data->nm_barang); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group">
                            <label for="input3" class="form-label">Nama Ukuran Bahan</label>
                            <input type="text" class="form-control" name="nm_ukuran_bahan" id="input3" value="<?php echo e($tampil->nm_ukuran_bahan); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group">
                            <label for="input6" class="form-label">Minimal Range</label>
                            <input type="number" class="form-control" name="range_min" step="0.01" min="0" value="<?php echo e(number_format($tampil->range_min, 2)); ?>" id="input_kn" placeholder="x.01" required>
                        </div>
                    </div>
                        <div class="col-md-12 col-lg-12">
                            <div class="form-group">
                                <label for="input6" class="form-label">Maximal Range</label>
                                <input type="number" class="form-control" name="range_max" step="0.01" min="<?php echo e(number_format($tampil->range_max, 2)); ?>" value="<?php echo e(number_format($tampil->range_max, 2)); ?>" id="input_kn" placeholder="x.99" required>
                            </div>
                        </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
        		</form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>
<!-- End Modal Code -->