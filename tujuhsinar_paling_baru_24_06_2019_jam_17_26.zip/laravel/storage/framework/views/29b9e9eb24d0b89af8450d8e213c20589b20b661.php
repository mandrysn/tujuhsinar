<!-- Start Modal Code -->
<!-- Link -->
<!-- Modal -->
<?php $__empty_1 = true; $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="modal fade bs-example" id="edit-<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Admin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-12">
        		    <form method="post" action="<?php echo e(route('pengguna.update', $data->id)); ?>">
        			<?php echo csrf_field(); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="col-md-12 col-lg-12">
                        <div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
                            <label for="input1" class="form-label">Nama</label>
                            <input type="text" id="input1" name="nama" class="form-control" value="<?php echo e($data->nama); ?>" required>
                            <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('nama')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                            <label for="input3" class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" value="<?php echo e($data->username); ?>" required>
                            <?php if($errors->has('username')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('username')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group<?php echo e($errors->has('lama') ? ' has-error' : ''); ?>">
                            <label for="input7" class="form-label">Password Lama</label>
                            <input type="password" id="input1" name="lama" class="form-control" value="">
                            <?php if($errors->has('lama')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('lama')); ?></strong>
                            </span>
                            <?php else: ?>
                            <span class="help-block">
                                <strong>Kosongkan bila tidak ada perubahan password*</strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group<?php echo e($errors->has('baru') ? ' has-error' : ''); ?>">
                            <label for="input7" class="form-label">Password Lama</label>
                            <input type="password" class="form-control" name="baru" value="">
                            <?php if($errors->has('baru')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('baru')); ?></strong>
                            </span>
                            <?php else: ?>
                            <span class="help-block">
                                <strong>Kosongkan bila tidak ada perubahan password*</strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group<?php echo e($errors->has('no_telp') ? ' has-error' : ''); ?>">
                            <label for="input4" class="form-label">Nomor Telpon</label>
                            <input type="text" id="input4" name="no_telp" class="form-control" value="<?php echo e($data->no_telp); ?>" required>
                            <?php if($errors->has('no_telp')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('no_telp')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group<?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
                            <label for="input6" class="form-label">Alamat</label>
                            <input type="text" class="form-control" name="alamat" value="<?php echo e($data->alamat); ?>" required>
                            <?php if($errors->has('alamat')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('alamat')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <?php if(Auth::user()->id == 1): ?>
                        <div class="form-group">
                            <label for="select2" class="form-label">Sebagai</label>
                            <select class="selectpicker form-control" data-live-search="true" name="role" id="select2" required>
                                    <option value="2" <?php echo e(($data->role == 2) ? 'selected' : ''); ?>>Order</option>
                                    <option value="3" <?php echo e(($data->role == 3) ? 'selected' : ''); ?>>Kasir</option>
                                    <option value="5" <?php echo e(($data->role == 5) ? 'selected' : ''); ?>>Owner</option>
                                    <option value="6" <?php echo e(($data->role == 6) ? 'selected' : ''); ?>>Outdoor</option>
                                    <option value="7" <?php echo e(($data->role == 7) ? 'selected' : ''); ?>>Indoor</option>
                                    <option value="8" <?php echo e(($data->role == 8) ? 'selected' : ''); ?>>Merchandise</option>
                                    <option value="9" <?php echo e(($data->role == 9) ? 'selected' : ''); ?>>Print</option>
                                    <option value="10" <?php echo e(($data->role == 10) ? 'selected' : ''); ?>>Costum</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
        		</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>
<!-- End Modal Code -->