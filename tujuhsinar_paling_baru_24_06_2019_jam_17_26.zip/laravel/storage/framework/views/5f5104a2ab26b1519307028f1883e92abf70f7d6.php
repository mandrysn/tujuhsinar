<?php $__env->startSection('title', 'Pembelian'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-padding animated fadeInRight"> 
		<div class="row"> 
			<!-- Start Panel -->
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-title"> Data Pembelian </div>
					<div class="panel-body table-responsive">
						<table id="example0" class="table display">
							<thead>
								<tr>
									<th>No.</th>
									<th>Order</th>
									<th>Pelanggan</th>
									<th>Tanggal Order</th>
									<th>Pembayaran</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody id="list_order">
								<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr id="order-<?php echo e($datas->id); ?>" class="listnya">
									<td><?php echo e($index + 1); ?></td>
									<td><?php echo e($datas->order); ?></td>
									<td><?php echo e($datas->pelanggan->nama); ?></td>
									<td><?php echo e(Helper::tanggalId($datas->tanggal)); ?></td>
									<td><?php echo e($datas->status_payment); ?></td>
									<td><a href="<?php echo e(route('order.show', $datas->id)); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Detail</a></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>
							</tbody>
							<tfoot>
								
							</tfoot>
						</table>
					</div>
				</div>
			</div>
			<!-- End Panel --> 
		</div>
		<!-- End Row --> 
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>