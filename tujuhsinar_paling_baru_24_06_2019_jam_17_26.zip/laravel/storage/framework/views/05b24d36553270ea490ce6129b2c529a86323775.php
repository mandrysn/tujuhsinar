<?php $__env->startSection('title', 'Data Produksi'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-padding animated fadeInRight"> 
		<div class="row"> 
			<!-- Start Panel -->
			<div class="col-md-12">
				<?php if(Session::has('alert-success')): ?>
					<div class="foxlabel-alert foxlabel-alert-icon alert3"> <i class="fa fa-check"></i> <a href="#" class="closed">&times;</a> <?php echo e(\Illuminate\Support\Facades\Session::get('alert-success')); ?></div>
				<?php endif; ?>
				<div class="panel panel-default">
					<div class="panel-title"> Data Produksi </div>
					<div class="panel-body table-responsive">
						<table id="example0" class="table display">
							<thead>
								<tr>
									<th>No.</th>
									<th>Jenis Order</th>
									<th>Total Order</th>
									<th>Antrian</th>
									<th>Printing</th>
									<th colspan="2">Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($index + 1); ?></td>
									<td><?php echo e($datas->nama_produk); ?></td>
									<td><?php echo e($datas->produk); ?></td>
									<td><?php echo e(Helper::totalAntrian($datas->produk_id)); ?></td>
									<td><?php echo e(Helper::totalPrinting($datas->produk_id)); ?></td>
									<td>						
										<a href="<?php echo e(route('produksi.show', strtolower($datas->nama_produk))); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Detail</a>

										<?php if($datas->status_produksi == '1'): ?>
										<a href="<?php echo e(route('produksi.edit', $datas->id)); ?>" class="btn btn-option2"><i class="fa fa-check"></i> Order</a>
										<?php elseif($datas->status_produksi == '2'): ?>
										<a href="<?php echo e(route('produksi.edit', $datas->id)); ?>" class="btn btn-option2"><i class="fa fa-stack-overflow"></i> Selesai</a>
										<?php elseif($datas->status_produksi == '3'): ?>
										<a class="btn btn-option3"><i class="fa fa-cubes"></i> Selesai</a>
										<?php endif; ?>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>
							</tbody>
							<tfoot>
									
							</tfoot>
						</table>
					</div>
				</div>
			</div>
			<!-- End Panel --> 
		</div>
		<!-- End Row --> 
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>