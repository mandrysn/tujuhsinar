<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="NOTA KASIR TUJUH SINAR">
    <meta name="author" content="MAndrySN.GreenNusa">
    <link href="<?php echo e(asset('css/styles_cetak.css')); ?>" rel="stylesheet" type="text/css">
    <title>NOTA KASIR TUJUH SINAR</title>
    <script type="text/javascript">
        window.print();
        
    </script>
</head>

<body >
    <header>
        <table cellspacing="0" cellpadding="1">
            <tr>
                <td width="40%" colspan="5" align="left" valign="top">
                <span style="font-size: 24px">Toedjoe Sinar Group</span><br />
                <br>
                M Yamin
                </td>
                <td width="20%"></td>
                <td width="10%">
                    <br /><br />
                    <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($order->order, 'CODABAR')); ?>" height="30" width="110">
                </td>
                <td width="5%"></td>
                <td width="60%" colspan="5" align="left" valign="top">
                    <br ><br />
                    No. Invoice/Nota : <?php echo e($order->order); ?> <br>
                    Kepada Yth <br>
                    <?php echo e($order->pelanggan->nama); ?> <br>
                    Telp : <?php echo e($order->pelanggan->no_telp); ?> <br>
                    
                    Tanggal pemesanan : <?php echo e(Helper::tanggalId($order->tanggal)); ?>

                
                </td>
                
            </tr>
            <tr>
                <td width="40%"></td>
                <td rowspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="5" align="left" valign="top">
                &nbsp;
                </td>
                <td colspan="5" align="left" valign="top">
                    &nbsp;
                </td>
            </tr>
        </table>
    </header>

    <main>
        <div class="main">
        <table class="table-header" width="100%">
            <tr><th colspan="5" align="left">Bahan</th></tr>
            <tr> 
                <td  width="5%" align="center">
                    Qty
                </td>
                <td  width="20%" class="border-left" align="center">
                    Nama File
                </td>
                <td  width="10%" class="border-left" align="center">
                    Tipe Produk
                </td>
                <td  width="15%" class="border-left" align="center">
                    Harga Satuan
                </td>
                <td  width="12%" class="border-left" align="right">
                    Total
                </td>
            </tr>
        </table>
        
        <table class="table-list" width="100%">

            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <td colspan="5" valign="top">
                    <?php echo e($index + 1); ?>.&nbsp;<?php echo e($datas->Barang->nm_barang); ?>

                </td>
            </tr>
            <tr>
                <td  width="5%" align="center" valign="top">
                    <strong><?php echo e($datas->qty); ?></strong>
                </td>
                <td width="20%" align="center" valign="top">
                    <strong><?php echo $datas->keterangan_sub; ?></strong>
                </td>
                <td width="10%" align="center" valign="top">
                    <strong><?php echo e($datas->nama_produk); ?></strong>
                </td>
                <td width="15%" align="center" valign="top">
                    <strong><?php echo e(number_format($datas->harga)); ?></strong>
                </td>
                <td  width="12%" align="right" valign="top">
                    <strong><?php echo e(number_format($datas->total)); ?></strong>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>

        </table>

        <table class="table-foot" width="100%">
            <tr>
                <td colspan="5" align="left" width="71%">
                    <strong>Pembayaran <?php echo e($order->status_payment); ?>. <?php echo e(str_replace("<br />", ". ", $order->keterangan)); ?></strong>
                </td>
                <td class="border-left" align="right">
                    <strong><?php echo e(number_format($totalan->total)); ?></strong>
                </td>
            </tr>
        </table>
        </div>
    </main>

    <footer>
        <table width="100%" >
            <tr>
                <td width="60%" align="left" valign="top">
                    Catatan :<br />
                    1.  Periksa Kembali File Sebelum Cetak, Kesalahan Setelah Cetak Bukan tanggung jawab Management Toedjoe Sinar Group <br />
                    2. Wajib DP min 50% dari Total Biaya Cetak <br />
                    3. 1 (SATU) bulan barang tidak diambil, bukan tanggung jawab management Toedjoe Sinar Group<br />
                    4. Pembayaran dianggap SAH apabila menunjukkan bukti transfer.
                </td>
                <td width="20%" align="left" valign="top">
                Kasir<br />
                Tanggal:<br /><br /><br />
                ADMIN
                </td>
                <td width="10%" align="left" valign="top">
                Penerima<br />
                Tanggal:<br /><br /><br />
                Nama jelas:
                </td>
            </tr>
        </table>
    </footer>

</body>

</html>