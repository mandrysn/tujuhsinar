<?php $__env->startSection('title', 'Data Bahan'); ?>
<?php $__env->startSection('content'); ?>

		<div class="row"> 
			<!-- Start Panel -->
			<div class="col-md-12">
				<?php if(Session::has('alert-barang')): ?>
					<div class="foxlabel-alert foxlabel-alert-icon alert3"> <i class="fa fa-check"></i> <a href="#" class="closed">&times;</a> <?php echo e(\Illuminate\Support\Facades\Session::get('alert-barang')); ?></div>
				<?php elseif($errors->has('barcode')): ?>
                    <div class="foxlabel-alert foxlabel-alert-icon alert6"> <i class="fa fa-close"></i> <a href="#" class="closed">&times;</a><?php echo e($errors->first('barcode')); ?></div>
                <?php endif; ?>
				<div class="panel panel-default">
					<a href="#" data-toggle="modal" data-target="#tambah" class="btn btn-default"><i class="fa fa-plus-circle"></i>Tambah Bahan</a>
					<br>
					<br>
					<div class="panel-title"> Data Bahan </div>
					<div class="panel-body table-responsive">
						<table id="example0" class="table display">
							<thead>
								<tr>
									<th>No.</th>
									<th>Barcode</th>
									<th>Tipe Cetak</th>
									<th>Kategori</th>
									<th>Satuan</th>
									<th>Supplier</th>
									<th>Harga Beli</th>
									<th>Min. Stok</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($index + 1); ?></td>
									<td><?php echo e($datas->barcode); ?></td>
									<td><?php echo e($datas->tipe_produk); ?></td>
									<td><?php echo e($datas->kategori); ?></td>
									<td><?php echo e($datas->satuan); ?></td>
									<td><?php echo e($datas->supplier->nm_lengkap); ?></td>
									<td><?php echo e(number_format($datas->hrg_beli)); ?></td>
									<td><?php echo e($datas->min_stok); ?></td>
									<td>
										<form action="<?php echo e(route('barang.destroy', $datas->id)); ?>" method="post">
											<?php echo e(csrf_field()); ?>

											<?php echo e(method_field('DELETE')); ?>

											<button class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ?')"><i class="fa fa-check"></i>Delete</button>
										</form>
										<button href="#" data-toggle="modal" data-target="#edit-<?php echo e($datas->id); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Edit</button>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>
							<tfoot>

							</tfoot>
						</table>
					</div>
				</div>
			</div>
			<!-- End Panel --> 
		</div>
		<!-- End Row --> 
	<?php echo $__env->make('master.tools.barang.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->make('master.tools.barang.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('master.tools.barang.pilih_supplier', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>