<?php $__env->startSection('title', 'Pembelian'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-padding animated fadeInRight"> 
		<div class="row"> 
			<!-- Start Panel -->
			<div class="col-md-12">
				<?php if(Session::has('alert-success')): ?>
					<div class="foxlabel-alert foxlabel-alert-icon alert3"> <i class="fa fa-check"></i> <a href="#" class="closed">&times;</a> <?php echo e(\Illuminate\Support\Facades\Session::get('alert-success')); ?></div>
				<?php endif; ?>
				<div class="panel panel-default">
					<a href="<?php echo e(route('order.index')); ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i>Kembali</a>
					
					<br>
					<br>
					<div class="panel-title"> Data Pembelian Yang Di Cancel </div>
					<div class="panel-body table-responsive">
						<table id="example0" class="table display">
							<thead>
								<tr>
									<th>No.</th>
									<th>Order</th>
									<th>Pelanggan</th>
									<th>Tanggal Order</th>
									<th>Pembayaran</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody id="list_order">
								<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr id="order-<?php echo e($datas->id); ?>" class="listnya">
									<td><?php echo e($index + 1); ?></td>
									<td><?php echo e($datas->order); ?></td>
									<td><?php echo e($datas->pelanggan->nama); ?></td>
									<td><?php echo e(Helper::tanggalId($datas->tanggal)); ?></td>
									<td><?php echo e($datas->status_payment); ?></td>
									<td>
																	
										<form action="<?php echo e(route('order.destroy', $datas->id)); ?>" class="form-horizontal" method="post">
											<?php echo e(csrf_field()); ?>

											<?php echo e(method_field('DELETE')); ?>


										<a href="<?php echo e(route('order.show', $datas->id)); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Detail</a>

										<?php if(Auth::user()->role == 2 || Auth::user()->role == 1): ?>
										<button class="btn btn-danger" <?php if($datas->status_payment != 'belum bayar'): ?> disabled <?php endif; ?> onclick="return confirm('Yakin ingin menghapus data ?')"><i class="fa fa-check"></i>Delete</button>
										<?php endif; ?>
										</form>
										
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>
							</tbody>
							<tfoot>
								
							</tfoot>
						</table>
					</div>
				</div>
			</div>
			<!-- End Panel --> 
		</div>
		<!-- End Row --> 
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>