<?php $__env->startSection('title', 'Data Pengguna'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Start Panel -->
<div class="col-md-12">
    <?php if(Session::has('alert-user')): ?>
        <div class="foxlabel-alert foxlabel-alert-icon alert3"> <i class="fa fa-check"></i> <a href="#" class="closed">&times;</a> <?php echo e(\Illuminate\Support\Facades\Session::get('alert-user')); ?></div>
    <?php endif; ?>
    <div class="panel panel-default">
        <a href="#" data-toggle="modal" data-target="#tambah" class="btn btn-default"><i class="fa fa-plus-circle"></i>Tambah Admin</a>
        <br>
        <br>
        <div class="panel-title"> Data Petugas </div>
        <div class="panel-body table-responsive">
            <table id="example0" class="table display">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Nomor Telepon</th>
                        <th>Alamat</th>
                        <th>Sebagai</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($datas->nama); ?></td>
                        <td><?php echo e($datas->username); ?></td>
                        <td><?php echo e($datas->no_telp); ?></td>
                        <td><?php echo e($datas->alamat); ?></td>
                        <td><?php echo e($datas->Tugas); ?></td>
                        <td>
                            <form action="<?php echo e(route('pengguna.destroy', $datas->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <a href="#" data-toggle="modal" data-target="#edit-<?php echo e($datas->id); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Edit</a>
                            <?php if($datas->role == 1): ?>
                            <?php elseif($datas->id == Auth::user()->id): ?>
                            <?php else: ?>
                            <button class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ?')"><i class="fa fa-check"></i>Delete</button>
                            <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
        </div>
    </div>
</div>
<!-- End Panel -->
</div>
<?php echo $__env->make('user.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('user.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>