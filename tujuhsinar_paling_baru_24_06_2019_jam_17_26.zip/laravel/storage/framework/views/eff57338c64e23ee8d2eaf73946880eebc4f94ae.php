<?php 
    header("Content-type: application/octet-stream");
    header("Content-Disposition: attachment; filename=rekap-data-tunai.xls");
    header("Pragma: no-cache");
    header("Expires: 0");
 ?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="A Components Mix Bootstarp 3 Admin Dashboard Template">
    <meta name="author" content="Westilian">
    <title>Laporan Tunai</title>
    
</head>

<body>
    <table>
                <thead>
                    <tr>
                            <th data-toggle="true">No</th>
                            <th data-hide="all">No Order</th>
                            <th data-hide="phone">Costumer</th>
                            <th data-hide="all">Keterangan</th>
                            <th data-hide="phone">Deadline</th>
                            <th data-hide="phone" >Bahan</th>
                            <th data-hide="phone" >Estimasi</th>
                            <th data-hide="phone" >Qty</th>
                                </tr>
                </thead>
                <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>'<?php echo e($datas->orderkerja->order); ?></td>
                            <td><?php echo e($datas->orderkerja->pelanggan->nama); ?></td>
                            <td><?php echo $datas->keterangan_sub; ?></td>
                            <td><?php echo e(Helper::tanggalId($datas->deadline)); ?></td>
                            <td><?php echo e(is_null($datas->barang_id) ? '-' : $datas->barang->nm_barang); ?></td>
                            <td><?php echo e(number_format($datas->harga)); ?></td>
                            <td><?php echo e($datas->qty); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                </tbody>
                <tfoot>

                </tfoot>
    </table>
</body>

</html>