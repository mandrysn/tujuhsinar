<?php $__env->startSection('title', 'Data Produksi'); ?>
<?php $__env->startSection('content'); ?>

<div class="row"> 
    <!-- Start Panel -->
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-title"> Data Produksi </div>
            <div class="panel-body table-responsive">
                
						<table class="footable table table-stripped toggle-arrow-tiny" data-page-size="15">
							<thead>
								<tr>

                                    <th data-toggle="true">No</th>
                                    <th data-hide="all">No Order</th>
									<th data-hide="phone">Costumer</th>
                                    <th data-hide="all">Keterangan</th>
                                    <th data-hide="all">Pembayaran</th>
                                    <th data-hide="phone">Deadline</th>
                                    <th data-hide="phone" >Bahan</th>
                                    <th data-hide="phone" >Estimasi</th>
                                    <th data-hide="phone" >Qty</th>
									<th class="text-right" data-sort-ignore="true">Action</th>

								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($datas->orderkerja->order); ?></td>
									<td><?php echo e($datas->orderkerja->pelanggan->nama); ?></td>
                                    <td><?php echo $datas->keterangan_sub; ?></td>
                                    <td><?php echo $datas->keterangan; ?></td>
                                    <td><?php echo e(Helper::tanggalId($datas->deadline)); ?></td>
                                    <td><?php echo e(is_null($datas->barang_id) ? '-' : $datas->barang->nm_barang); ?></td>
                                    <td><?php echo e(number_format($datas->harga)); ?></td>
                                    <td><?php echo e($datas->qty); ?></td>
									<td class="text-right">
										<div class="btn-group">
											
                                            <?php if($datas->status_produksi == '1'): ?>
                                            <a class="btn-white btn btn-xs" onclick="return confirm('Yakin ingin mencetak data ini ?')" href="<?php echo e(route('produksi.update_status',$datas->id)); ?>"><i class="fa fa-check"></i>Antrian</a>
                                            <?php elseif($datas->status_produksi == '2'): ?>
                                            <a class="btn-white btn btn-xs" onclick="return confirm('Apakah produksi telah selesai ?')" href="<?php echo e(route('produksi.update_status',$datas->id)); ?>"><i class="fa fa-refresh"></i>Printing</a>
                                            <?php elseif($datas->status_produksi == '3'): ?>
                                            <a class="btn-white btn btn-xs" ><i class="fa fa-cubes"></i>Selesai</a>
                                            
                                            <?php endif; ?>
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>

							</tbody>
							<tfoot>
								<tr>
									<td colspan="10">
										<nav aria-label="Page navigation example">
											<ul class="pagination pull-right"></ul>
										</nav>
									</td>
								</tr>
							</tfoot>
						</table>
            </div>
        </div>
    </div>
    <!-- End Panel --> 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>