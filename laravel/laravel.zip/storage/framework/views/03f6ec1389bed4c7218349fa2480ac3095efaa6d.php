<?php $__env->startSection('title', 'Tambah Data Order'); ?>
<?php $__env->startSection('content'); ?>
<?php if( ! is_null($order->keterangan) ): ?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-title"> Status Order
                <ul class="panel-tools">
                    <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
                </ul> 
            </div>
            <div class="panel-body">
                                <form >
                <div id="outdoor_show" class="row col-md-12">
                 <div class="col-md-12 col-lg-2">
                     <div class="form-group">
                        <label for="input2" class="form-label">No</label>
                        <input type="text" class="form-control" name="noorder" required disabled value="<?php echo e($order->order); ?>">
                    </div>
                </div>

                <div class="col-md-12 col-lg-4">
                    <div class="form-group">
                        <label for="select2" class="form-label">Customer</label>
                        <input type="hidden" id="idmember" name="member_id" value="<?php echo e($order->pelanggan->member_id); ?>">
                        <input type="text" class="form-control" name="customer_id" required disabled value="<?php echo e($order->pelanggan->nama); ?> [<?php echo e($order->pelanggan->member->nm_tipe); ?>]">
                        
                    </div>

                </div>
        
                <div class="col-md-12 col-lg-3">
                    <div class="form-group">
                        <label class="form-label">Tanggal Order</label>
                        <fieldset>
                            <div class="control-group">
                                <div class="controls">
                                    <div class="input-prepend input-group"> 
                                        <input type="text" id="date-picker" class="form-control" name="tanggal" value="<?php echo e(Helper::tanggalId($order->tanggal)); ?>" disabled required>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div> 

                
            </div>
        </form>
                <h1><?php echo trim($order->keterangan); ?></h1>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-title"> Total Harga
                <ul class="panel-tools">
                    <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
                </ul> 
            </div>
            <div class="panel-body">
                <h1>Rp. <?php echo e(number_format($totalan->total)); ?></h1>
            </div>
        </div>
    </div>
</div>

<div class="row"> 
    <!-- Start Panel -->
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-title"> Data Pekerjaan </div>
            <?php if($order->status_payment == 'belum bayar'): ?>
                <?php if(Auth::user()->role == 2 || Auth::user()->role == 1): ?>
                    <a href="<?php echo e(route('order.edit', $id)); ?>" class="btn btn-default"><i class="fa fa-plus-circle"></i>Tambah Order</a>
                <?php endif; ?>

                <?php if(Auth::user()->role == 3 || Auth::user()->role == 1): ?>
                    <a href="#" data-toggle="modal" data-target="#edit-data<?php echo e($id); ?>" class="btn btn-option2"><i class="fa fa-money"></i> Pembayaran</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('order.print', $id)); ?>" class="btn btn-option2"><i class="fa fa-money"></i> Print Nota</a>
            <?php endif; ?>
            <a href="<?php echo e(route('order.index')); ?>" class="btn btn-default">Kembali</a>

            <br>
            <br>
            <div class="panel-body table-responsive">
                <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Deadline</th>
                            <th>Produk</th>
                            <th>Bahan</th>
                            <th>Diskon</th>
                            <th>Qty</th>
                            <th>Total Harga</th>
                            <th>Keterangan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <th><?php echo e(Helper::tanggalId($datas->deadline)); ?></th>
                            <td><?php echo e($datas->nama_produk); ?></td>
                            <td><?php echo e(is_null($datas->barang_id) ? '-' : $datas->barang->nm_barang); ?></td>
                            <td><?php echo e($datas->diskon); ?> %</td>
                            <td><?php echo e($datas->qty); ?></td>
                            <td>Rp. <?php echo e(number_format($datas->total)); ?></td>
                            <td><?php echo $datas->keterangan_sub; ?></td>
                            <td>
                                <?php if($datas->status_produksi == '1'): ?>
                                Antrian
                                <?php elseif($datas->status_produksi == '2'): ?>
                                Printing
                                <?php elseif($datas->status_produksi == '3'): ?>
                                Selesai
                                <?php else: ?>
                                Sudah diambil
                                <?php endif; ?>
                            </td>
                            <td>
                                <form action="<?php echo e(route('order.subkerja.hapus', $datas->id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button <?php if($order->status_payment != 'belum bayar'): ?> disabled <?php endif; ?> class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ?')"><i class="fa fa-trash"></i>Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>

                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <!-- End Panel --> 
</div>

<?php echo $__env->make('transaksi.order.pembayaran', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>