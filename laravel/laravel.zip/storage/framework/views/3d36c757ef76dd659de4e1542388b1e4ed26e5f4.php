<form method="post" action="<?php echo e(route('storeOutdoor')); ?>" >
	<?php echo csrf_field(); ?>

	<?php echo e(Form::hidden('harga', '', ['id' => 'harga'])); ?>

	<?php echo e(Form::hidden('diskon', '', ['id' => 'diskon'])); ?>

	<?php echo e(Form::hidden('produk_id', '1', ['id' => 'produk'])); ?>

	<?php echo e(Form::hidden('order', $order->order, ['id' => 'order'])); ?>

    <?php echo e(Form::hidden('pelanggan_id', $order->pelanggan_id, ['id' => 'pelanggan', 'oninput' => 'get_card_name()'])); ?>

	
	<div class="row">
		<div class="col-md-12 col-lg-4">
			<div class="form-group">
				<label for="input3" class="form-label">Produk</label>
				<select class="selectpicker form-control" name="barang_id" data-live-search="true" onchange="get_card_name()" id="barang" required>
					<option disable>-- Pilih Produk --</option>
					<?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($barang->produk_id == 1): ?>
							<option value="<?php echo e($barang->id); ?>"><?php echo e($barang->nm_barang); ?></option>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-md-12 col-lg-2">
			<div class="form-group">
				<label for="inputp" class="form-label">Panjang (Meter)</label>
				<input type="number" class="form-control" id="panjang" oninput="get_card_name()" value="0.00" min="0" name="panjang" step="0.01" value="0.00" required>
			</div>
		</div>
		<div class="col-md-12 col-lg-2">
			<div class="form-group">
				<label for="inputl" class="form-label">Lebar (Meter)</label>
				<input type="number" class="form-control" id="lebar" oninput="get_card_name()" value="0.00" min="0" name="lebar" step="0.01" value="0.00" required>
			</div>
		</div>

		<div class="col-md-12 col-lg-4">
			<div class="form-group">
				<label class="form-label">Nama File</label>
				<input type="text" name="nama_file" class="form-control" required>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12 col-lg-3">
			<div class="form-group">
				<label class="form-label">Tanggal Deadline</label>
				<input type="date" class="form-control" id="pilih_deadline_outdoor" style="display: inline-block;" name="deadline" required>
			</div>
		</div>

		<div class="col-md-12 col-lg-3">
			<div class="form-group">
				<label for="" class="form-label">Finishing</label>
				<select class="form-control" name="editor_id" id="editor_id">
					<option selected>-- Pilih Finishing --</option>
					<?php $__currentLoopData = $editors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($editor->produk_id == 1): ?>
							<option value="<?php echo e($editor->id); ?>"><?php echo e($editor->nama_finishing); ?> - <?php echo e(number_format($editor->tambahan_harga)); ?></option>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-md-12 col-lg-3">
			<div class="form-group">
				<label for="" class="form-label">Kaki</label>
				<select class="form-control" name="kaki_id" id="kaki_id">
					<option selected>-- Pilih Kaki --</option>
					<?php $__currentLoopData = $kakis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kaki): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($kaki->produk_id == 1): ?>
							<option value="<?php echo e($kaki->id); ?>"><?php echo e($kaki->nama_kaki); ?> - <?php echo e(number_format($kaki->tambahan_harga)); ?></option>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-md-12 col-lg-1">
			<div class="form-group">
				<label for="input6" class="form-label">Qty</label>
				<input type="text" class="form-control" name="qty" oninput="get_card_name()" id="qty" required>
			</div>
		</div>

		
		<div class="col-md-12 col-lg-2">
			
			<div class="form-group">
				<label for="" class="form-label">Total Harga</label>
				<input type="text" class="form-control" name="total" id="total" readonly placeholder="Total" required>
			</div>
		</div>

		<div class="col-md-12 col-lg-4">
			<button type="submit" class="btn btn-primary" id="OSub" disabled>Submit</button>
			<a href="<?php echo e(URL(Helper::backButton())); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Kembali</a>
		</div>
	</div>	

</form>

<?php $__env->startPush('style'); ?>
<script type="text/javascript">

    function get_card_name() {
		var pelanggan = document.getElementById("pelanggan").value;
  		var barang = document.getElementById("barang").value;
		var p = document.getElementById("panjang").value;
		var l = document.getElementById("lebar").value;
		var qty = document.getElementById("qty").value;

		if(pelanggan != '' && barang != '' && qty != '' && l != '' && p != '' && pelanggan != null && barang != null && qty != null && l != null && p != null) {

			jQuery.ajax({
	        	
	            url: "<?php echo e(url('admin/transaksi/order/outdoor/data/')); ?>/"+barang+"/"+pelanggan+"/"+qty+"/"+p+"/"+l,
	            type: "GET",
	            success: function(data) {
	                jQuery('#diskon').val(data.diskon);
	                jQuery('#total').val(data.total);
					jQuery('#harga').val(data.harga);
					
						if(data.total > 0 || data.total != '') {
							jQuery('#OSub').removeAttr('disabled');
						} else {
							jQuery('#OSub').attr('disabled', 'disabled');
						}
	            }
			});
		
		}

        
    }
</script>
<?php $__env->stopPush(); ?>