<?php $__env->startSection('title', 'Pembelian'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-padding animated fadeInRight">
<!-- Start Row -->
<div id="tour-12" class="row">
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="mini-stat clearfix bg-twitter rounded"> 
            <a href="<?php echo e(route('laporan.order')); ?>">
                <span class="mini-stat-icon"><i class="la la-dashboard"></i></span>
                <div class="mini-stat-info"> 
                    <span class="counter" data-counter="counterup" data-value="<?php echo e($order); ?>">0</span> Laporan Order 
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="mini-stat clearfix bg-twitter rounded"> 
            <a href="<?php echo e(route('laporan.indoor')); ?>">
                <span class="mini-stat-icon"><i class="la la-calendar-check-o"></i></span>
                <div class="mini-stat-info"> 
                    <span class="counter" data-counter="counterup" data-value="<?php echo e($indoor); ?>">0</span> Order Indoor 
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="mini-stat clearfix bg-twitter rounded"> 
            <a href="<?php echo e(route('laporan.outdoor')); ?>">
                <span class="mini-stat-icon"><i class="la la-calendar-minus-o"></i></span>
                <div class="mini-stat-info"> 
                    <span class="counter" data-counter="counterup" data-value="<?php echo e($outdoor); ?>">0</span> Order Outdoor 
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="mini-stat clearfix bg-twitter rounded"> 
            <a href="<?php echo e(route('laporan.merchandise')); ?>">
                <span class="mini-stat-icon"><i class="la la-calendar-o"></i></span>
                <div class="mini-stat-info"> 
                    <span class="counter" data-counter="counterup" data-value="<?php echo e($merchandise); ?>">0</span> Order Merchandise 
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="mini-stat clearfix bg-twitter rounded"> 
            <a href="<?php echo e(route('laporan.print')); ?>">
                <span class="mini-stat-icon"><i class="la la-calendar-plus-o"></i></span>
                <div class="mini-stat-info"> 
                    <span class="counter" data-counter="counterup" data-value="<?php echo e($print); ?>">0</span> Order Print A3 
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="mini-stat clearfix bg-twitter rounded"> 
            <a href="<?php echo e(route('laporan.custom')); ?>">
                <span class="mini-stat-icon"><i class="la la-calendar-times-o"></i></span>
                <div class="mini-stat-info"> 
                    <span class="counter" data-counter="counterup" data-value="<?php echo e($custom); ?>">0</span> Order Costum 
                </div>
            </a>
        </div>
    </div>
</div>
<!-- End Row --> 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>