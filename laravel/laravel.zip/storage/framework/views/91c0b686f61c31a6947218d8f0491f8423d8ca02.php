<?php 
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=rekap-data-order.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
 ?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="A Components Mix Bootstarp 3 Admin Dashboard Template">
    <meta name="author" content="Westilian">
    <title>MatMix - A Components Mix Admin Dashboard Template</title>
    
</head>

<body>
    <table>
				<thead>
					<tr>
									<th>No.</th>
                                    <th>Order</th>
                                    <th>Member</th>
									<th>Pelanggan</th>
									<th>Tanggal Order</th>
                                    <th>Pembayaran</th>
                                    <th>Keterangan</th>
								</tr>
				</thead>
				<tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr id="order-<?php echo e($datas->id); ?>" class="listnya">
                            <td><?php echo e($index + 1); ?></td>
                            <td>'<?php echo e($datas->order); ?></td>
                            <td><?php echo e($datas->pelanggan->member->nm_tipe); ?></td>
                            <td><?php echo e($datas->pelanggan->nama); ?></td>
                            <td><?php echo e(Helper::tanggalId($datas->tanggal)); ?></td>
                            <td><?php echo e($datas->status_payment); ?></td>
                            <td><?php echo trim($datas->keterangan); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
				</tbody>
				<tfoot>

				</tfoot>
    </table>
</body>

</html>