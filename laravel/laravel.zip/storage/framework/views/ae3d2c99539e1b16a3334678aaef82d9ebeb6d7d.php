<!-- Start Modal Code -->
<!-- Link -->
<!-- Modal -->
<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="modal fade bs-example" id="edit-<?php echo e($tampil->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Kaki</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-12">
        		<form method="post" action="<?php echo e(route('kaki.update', $tampil->id)); ?>">
        			<?php echo csrf_field(); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="col-lg-12 col-md-12">
            			<div class="form-group">
            				<label for="select2" class="form-label">Tipe Member</label>
            				<select class="form-control" name="member_id" required>
            					<option value="">-- Pilih Member --</option>
            					<?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            					<option value="<?php echo e($datas->id); ?>" <?php echo e($tampil->member_id == $datas->id ? "selected" : ""); ?>><?php echo e($datas->nm_tipe); ?></option>
            					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            				</select>
            			</div>
            		</div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group">
                            <label for="input1" class="form-label">Nama Kaki</label>
                            <input type="text" class="form-control" name="nama_kaki" value="<?php echo e($tampil->nama_kaki); ?>" id="input1" required>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group">
                            <label for="input2" class="form-label">Harga Tambahan</label>
                            <input type="text" class="form-control" name="tambahan_harga" value="<?php echo e($tampil->tambahan_harga); ?>" id="input2" required>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12">
                        <div class="form-group">
                            <label for="select2" class="form-label">Tipe Cetak</label>
                            <select class="form-control" name="produk_id" required>
                                <option>-- Pilih Tipe Cetak --</option>
                                <option value="1" <?php echo e($tampil->produk_id == 1 ? "selected" : ""); ?>>Outdoor</option>
                                <option value="2" <?php echo e($tampil->produk_id == 2 ? "selected" : ""); ?>>Indoor</option>
                                <option value="3" <?php echo e($tampil->produk_id == 3 ? "selected" : ""); ?>>Merchant</option>
                                <option value="4" <?php echo e($tampil->produk_id == 4 ? "selected" : ""); ?>>Print A3</option>
                                <option value="5" <?php echo e($tampil->produk_id == 5 ? "selected" : ""); ?>>Costum</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
        		</form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>
<!-- End Modal Code -->