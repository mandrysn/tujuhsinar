<?php $__env->startSection('title', 'Pembelian'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-padding animated fadeInRight">
    <!-- Start Row -->
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-title">Pilih Periode</div>
                <div class="panel-body">
                    <div class="col-md-12 col-lg-4">
                        <form class="form-horizontal"  method="post" action="<?php echo e(route('laporan.detail.indoor')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                        <div class="input-prepend input-group"> <span class="add-on input-group-addon"><i class="fa fa-calendar"></i></span>
                                            <input type="text" id="date-range-picker" name="periode" class="form-control" value="2019-01-01 / <?php echo e(date('Y-m-d')); ?>" />
                                        </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <a href="<?php echo e(URL(Helper::backButton())); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Kembali</a>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Row --> 
                                        
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>