<?php $__env->startSection('title', 'Pembelian'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-padding animated fadeInRight"> 
		<div class="row"> 
			<!-- Start Panel -->
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-title">
						<form class="form-horizontal"  method="post" action="<?php echo e(route('laporan.cetak.order')); ?>">
							<?php echo csrf_field(); ?>

							<input type="hidden" name="periode" value="<?php echo e($periode); ?>" />
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Cetak</button>
                                    <a href="<?php echo e(URL(Helper::backButton())); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Kembali</a>
                                </div>
                        </form>
					</div>
					<div class="panel-body table-responsive">
    
						<table id="example0" class="table display">
				<thead>
					<tr>
									<th>No.</th>
                                    <th>Order</th>
                                    <th>Member</th>
									<th>Pelanggan</th>
									<th>Tanggal Order</th>
                                    <th>Pembayaran</th>
                                    <th>Keterangan</th>
								</tr>
				</thead>
				<tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr id="order-<?php echo e($datas->id); ?>" class="listnya">
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($datas->order); ?></td>
                            <td><?php echo e($datas->pelanggan->member->nm_tipe); ?></td>
                            <td><?php echo e($datas->pelanggan->nama); ?></td>
                            <td><?php echo e(Helper::tanggalId($datas->tanggal)); ?></td>
                            <td><?php echo e($datas->status_payment); ?></td>
                            <td><?php echo trim($datas->keterangan); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
				</tbody>
				<tfoot>

				</tfoot>
    </table>
					</div>
				</div>
			</div>
			<!-- End Panel --> 
		</div>
		<!-- End Row --> 
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>