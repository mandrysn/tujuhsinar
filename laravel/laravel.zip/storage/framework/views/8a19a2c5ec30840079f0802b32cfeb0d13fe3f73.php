<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-widget animated fadeInRight">
		
		<div class="row">
			<div class="col-lg-12">
				<div role="tabpanel">
						<div id="tour-12" class="row">
								
							<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
								<a href="<?php echo e(route('barang.index')); ?>">
									<div class="mini-stat clearfix bg-facebook rounded"> 
										<div class="mini-stat-info"> 
											Setting Bahan <br />
										</div>
									</div>
								</a>
							</div>

							<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
								<a href="<?php echo e(route('editor.index')); ?>">
									<div class="mini-stat clearfix bg-facebook rounded"> 
										<div class="mini-stat-info"> 
											Setting Finishing <br />
										</div>
									</div>
								</a>
							</div>

							<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
								<a href="<?php echo e(route('kaki.index')); ?>">
									<div class="mini-stat clearfix bg-facebook rounded"> 
										<div class="mini-stat-info"> 
											Setting Kaki <br />
										</div>
									</div>
								</a>
							</div>
							
						</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>