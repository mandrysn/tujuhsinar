<?php 
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=rekap-data-pelanggan.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
 ?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="A Components Mix Bootstarp 3 Admin Dashboard Template">
    <meta name="author" content="Westilian">
    <title>MatMix - A Components Mix Admin Dashboard Template</title>
    
</head>

<body>
    <table>
				<thead>
					<tr>
						<th>No</th>
						<th>ID Member</th>
						<th>Nama</th>
						<th>Alamat</th>
						<th>No. Telp/HP</th>
						<th>Email</th>
						<th>Tipe Member</th>
						<th>Pesanan Outdoor</th>
						<th>Pesanan Indoor</th>
						<th>Pesanan Print A3</th>
					</tr>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<?php ($id_pelanggan = $datas->id); ?>
					<tr>
						<td><?php echo e($index + 1); ?></td>
						<td>'<?php echo e(sprintf("%06s", $datas->id)); ?></td>
						<td><?php echo e($datas->nama); ?></td>
						<td><?php echo e($datas->alamat); ?></td>
						<td><?php echo e($datas->no_telp); ?></td>
						<td><?php echo e($datas->email); ?></td>
						<td><?php echo e($datas->member->nm_tipe); ?></td>
						<td><?php echo e(Helper::totalOutdoor($id_pelanggan)); ?> kali</td>
						<td><?php echo e(Helper::totalIndoor($id_pelanggan)); ?> kali</td>
						<td><?php echo e(Helper::totalPrint($id_pelanggan)); ?> kali</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
				</tbody>
				<tfoot>

				</tfoot>
    </table>
</body>

</html>