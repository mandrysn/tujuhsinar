<?php $__env->startSection('title', 'Data Finishing'); ?>
<?php $__env->startSection('content'); ?>

		<div class="row"> 
			<div class="col-md-12">
				<?php if( session()->has('alert-success') ): ?>
					<div class="foxlabel-alert foxlabel-alert-icon alert3"> <i class="fa fa-check"></i> <a href="#" class="closed">&times;</a> <?php echo e(session()->get('alert-success')); ?></div>
				<?php endif; ?>
				<div class="panel panel-default">
					<a href="#" data-toggle="modal" data-target="#tambah" class="btn btn-default"><i class="fa fa-plus-circle"></i>Tambah Finishing</a>
					<br>
					<br>
					<div class="panel-title"> Data Finishing </div>
					<div class="panel-body table-responsive">
						<table id="example0" class="table display">
							<thead>
								<tr>
									<th>No</th>
									<th>Tipe Finishing</th>
									<th>Tipe Member</th>
									<th>Nama Finishing</th>
									<th>Harga Tambahan</th>
									<th>Tipe Cetak</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($index + 1); ?></td>
									<td><?php echo e($datas->tipe_produk); ?></td>
									<td><?php echo e($datas->member->nm_tipe); ?></td>
									<td><?php echo e($datas->nama_finishing); ?></td>
									<td><?php echo e(number_format($datas->tambahan_harga)); ?></td>
									<td><?php echo e(Helper::get_type($datas->type)); ?></td>
									<td>
										<form action="<?php echo e(route('editor.destroy', $datas->id)); ?>" method="post">
											<?php echo e(csrf_field()); ?>

											<?php echo e(method_field('DELETE')); ?>

											<button class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ?')"><i class="fa fa-check"></i>Delete</button>
											<a href="#" data-toggle="modal" data-target="#edit-<?php echo e($datas->id); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Edit</a>
										</form>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>
							</tbody>
							<tfoot>

							</tfoot>
						</table>
					</div>
				</div>
			</div>
			<!-- End Panel --> 
		</div>
		<?php echo $__env->make('master.tools.finishing.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('master.tools.finishing.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>