<form method="post" action="<?php echo e(route('storePrintQuarto')); ?>" >
	<?php echo csrf_field(); ?>

	<?php echo e(Form::hidden('harga', '', ['id' => 'print_harga'])); ?>

	<?php echo e(Form::hidden('diskon', '', ['id' => 'print_diskon'])); ?>

	<?php echo e(Form::hidden('order', $order->order, ['id' => 'order'])); ?>

  <?php echo e(Form::hidden('pelanggan_id', $order->pelanggan_id, ['id' => 'print_pelanggan', 'oninput' => 'get_printer()'])); ?>


	<div class="row">
		<div class="col-md-12 col-lg-4">
			<div class="form-group">
				<label for="input3" class="form-label">Produk</label>
				<select class="selectpicker form-control" name="barang_id" data-live-search="true" id="print_barang" onchange="get_printer()" required >
					<option selected>-- Pilih produk --</option>
					<?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($barang->produk_id == 4): ?>
							<option value="<?php echo e($barang->id); ?>"><?php echo e($barang->nm_barang); ?></option>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-md-12 col-lg-4">
			<div class="form-group">
				<label class="form-label">Deadline</label>
				<input type="date" class="form-control" id="pilih_deadline_print" style="display: inline-block;" name="deadline">
			</div>
		</div>  

		<div class="col-md-12 col-lg-4">
			<div class="form-group">
				<label class="form-label">Keterangan</label>
				<input type="text" name="keterangan" class="form-control" required>
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-12 col-lg-2">
			<div class="form-group">
				<label for="ukuran">Ukuran</label> </label>
				<select class=" form-control" name="pilih_ukuran"  id="ukuran_print_a3" required onchange="get_printer()">
					<option selected>-- Pilih Ukuran --</option>
					<option value="1">A4</option>
					<option value="2">F4</option>
					<option value="3">A3</option>
				</select>
			</div>
		</div>
		
		<div class="col-md-12 col-lg-2" >
			<div class="form-group">
				<label for="input4" class="form-label">Tipe Print</label>
				<select class="form-control" name="tipe_print" id="pilih_tipe_print" required onchange="get_printer()">
					<option selected>--Pilih Tipe--</option>
					<option value="1">1 Sisi</option>
					<option value="2">2 Sisi</option>
				</select>
			</div>
		</div>

		<div class="col-md-12 col-lg-2">
			<div class="form-group">
				<label for="input6" class="form-label">Qty</label>
				<input type="text" class="form-control" name="qty" oninput="get_printer()" id="print_qty" required>
			</div>
		</div>


		<div class="col-md-12 col-lg-2">
			
			<div class="form-group">
				<label for="" class="form-label">Total Harga</label>
				<input type="text" class="form-control" name="total" id="print_total" readonly placeholder="Total" required>
			</div>
		</div>

		<div class="col-md-12 col-lg-4" style="margin-top: 28px;">
			<button type="submit" class="btn btn-primary" id="PSub" disabled>Submit</button>
			<a href="<?php echo e(URL(Helper::backButton())); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Kembali</a>
		</div>

	</div>
</form>

<?php $__env->startPush('style'); ?>
<script type="text/javascript">
    function get_printer() {
			var print_pelanggan = document.getElementById("print_pelanggan").value;
			var tipe_print = document.getElementById("pilih_tipe_print").value;
			var print_barang = document.getElementById("print_barang").value;
			var print_qty = document.getElementById("print_qty").value;
			var ukuran = document.getElementById("ukuran_print_a3").value;
		
			if (print_pelanggan != '' && print_barang != '' && print_qty != '' && tipe_print != '' && ukuran != '' && print_pelanggan != null && print_barang != null && print_qty != null && tipe_print != null && ukuran != null ) {
				jQuery.ajax({
					url: "<?php echo e(url('admin/transaksi/order/print/data/')); ?>/"+print_barang+"/"+print_pelanggan+"/"+print_qty+"/"+ukuran+"/"+tipe_print,
					type: "GET",
					success: function(data) {
							jQuery('#print_diskon').val(data.diskon);
							jQuery('#print_harga').val(data.harga);
							jQuery('#print_total').val(data.total);
							if(data.total > 0 || data.total != '') {
								jQuery('#PSub').removeAttr('disabled');
							} else {
								jQuery('#PSub').attr('disabled', 'disabled');
							}
					}
				});
			}
    }
</script>
<?php $__env->stopPush(); ?>