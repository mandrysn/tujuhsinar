<?php $__env->startSection('title', 'Tambah Harga'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 col-lg-12">
        <div class="widget-box">
            <div class="widget-title"> Data Harga Produk </div>
            <div role="tabpanel"> 
                
                <!-- Nav tabs -->
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item "><a class="btn btn-default" href="#outdoor" aria-controls="outdoor" role="tab" data-toggle="tab">Outdoor</a></li>
                    <li class="nav-item"><a class="btn btn-default" href="#indoor" aria-controls="indoor" role="tab" data-toggle="tab">Indoor</a></li>
                    <li class="nav-item"><a class="btn btn-default" href="#merchant" aria-controls="merchant" role="tab" data-toggle="tab">Merchandise</a></li>
                    <li class="nav-item"><a class="btn btn-default" href="#a3" aria-controls="a3" role="tab" data-toggle="tab">Print A3</a></li>
                    <li class="nav-item"><a class="btn btn-default" href="#costum" aria-controls="costum" role="tab" data-toggle="tab">Costum</a></li>
                </ul>
            </div>
        </div>

        <div class="widget-box">
            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane"  id="outdoor">
                        <?php echo $__env->make('master.harga.produk.outdoor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div role="tabpanel" class="tab-pane" id="indoor">
                        <?php echo $__env->make('master.harga.produk.indoor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div role="tabpanel" class="tab-pane" id="merchant">
                        <?php echo $__env->make('master.harga.produk.merchant', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div role="tabpanel" class="tab-pane" id="a3">
                        <?php echo $__env->make('master.harga.produk.a3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div role="tabpanel" class="tab-pane" id="costum">
                        <?php echo $__env->make('master.harga.produk.costum', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>