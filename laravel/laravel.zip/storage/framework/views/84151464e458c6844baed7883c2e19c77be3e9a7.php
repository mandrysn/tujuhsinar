<?php $__env->startSection('title', 'Edit Barang'); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
        <div class="col-md-12">
        <div class="panel panel-default">
        	<div class="panel-title"> Edit Data Barang
        		<ul class="panel-tools">
        			<li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
        			<li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
        			<li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
        		</ul>
        	</div>
        	<div class="panel-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<form method="post" action="<?php echo e(route('barang.update', $tampil->id)); ?>">
        			<?php echo csrf_field(); ?>

                    <?php echo e(method_field('PUT')); ?>

        			<div class="form-group">
        				<label for="input2" class="form-label">Barcode</label>
        				<input type="text" class="form-control" name="barcode" id="input2" value="<?php echo e($tampil->barcode); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="select2" class="form-label">Tipe Cetak</label>
                        <select class="form-control" name="produk_id" required>
                            <option>-- Pilih Tipe Cetak --</option>
                            <option value="1" <?php echo e($tampil->produk_id == 1 ? "selected" : ""); ?>>Outdoor</option>
                            <option value="2" <?php echo e($tampil->produk_id == 2 ? "selected" : ""); ?>>Indoor</option>
                            <option value="3" <?php echo e($tampil->produk_id == 3 ? "selected" : ""); ?>>Merchant</option>
                            <option value="4" <?php echo e($tampil->produk_id == 4 ? "selected" : ""); ?>>Print A3</option>
                            <option value="5" <?php echo e($tampil->produk_id == 5 ? "selected" : ""); ?>>Costum</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="input3" class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" name="nm_barang" id="input3" value="<?php echo e($tampil->nm_barang); ?>" required>
                    </div>
        			<div class="form-group">
        				<label for="input4" class="form-label">Kategori</label>
        				<input type="text" class="form-control" name="kategori" id="input4" value="<?php echo e($tampil->kategori); ?>" required>
        			</div>
                    <div class="form-group">
                        <label for="input5" class="form-label">Satuan</label>
                        <input type="text" class="form-control" name="satuan" id="input5" value="<?php echo e($tampil->satuan); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="input6" class="form-label">Harga Beli</label>
                        <input type="text" class="form-control" name="hrg_beli" id="input6" value="<?php echo e($tampil->hrg_beli); ?>" value="0" required>
                    </div>
                    <div class="form-group">
                        <label for="input6" class="form-label">Minimal Stok</label>
                        <input type="text" class="form-control" name="min_stok" id="input6" value="<?php echo e($tampil->min_stok); ?>" value="0" required>
                    </div>
                    <div class="form-group">
                        <label for="select2" class="form-label">Supplier</label>
                        <select class="form-control" name="supplier_id" required="">
                            <option value="">-- Pilih Member --</option>
                            <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($tampil2->id == $tampil->supplier_id): ?>
                            <option value="<?php echo e($tampil2->id); ?>" selected><?php echo e($tampil2->nm_lengkap); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($tampil2->id); ?>"><?php echo e($tampil2->nm_lengkap); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
        			<button type="submit" class="btn btn-primary">Submit</button>
                    <a href="<?php echo e(URL(Helper::backButton())); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Kembali</a>
        		</form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>