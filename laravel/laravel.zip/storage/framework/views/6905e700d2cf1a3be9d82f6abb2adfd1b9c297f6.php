<?php $__env->startSection('title', 'Edit Tipe Member'); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
        <div class="col-md-12">
        <div class="panel panel-default">
        	<div class="panel-title"> Edit Data Tipe Member
        		<ul class="panel-tools">
        			<li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
        			<li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
        			<li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
        		</ul>
        	</div>
        	<div class="panel-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<form method="post" action="<?php echo e(route('member.update', $tampil->id)); ?>">
        			<?php echo csrf_field(); ?>

                    <?php echo e(method_field('PUT')); ?>

        			<div class="form-group">
        				<label for="input1" class="form-label">Nama Tipe Member</label>
        				<input type="text" class="form-control" name="nm_tipe" id="input1" value="<?php echo e($tampil->nm_tipe); ?>" required>
        			</div>
        			<div class="form-group">
        				<label for="textarea1" class="form-label">Keterangan</label>
        				<textarea name="keterangan" class="form-control" required=""><?php echo e($tampil->keterangan); ?></textarea>
        			</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        			<button type="submit" class="btn btn-primary">Submit</button>
        			<a href="<?php echo e(URL(Helper::backButton())); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Kembali</a>
        		</form>
        	</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>