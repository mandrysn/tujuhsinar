<?php $__env->startSection('title', 'Tambah Petugas'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
        	<div class="panel-title"> Tambah Data Admin
        		<ul class="panel-tools">
        			<li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
        			<li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
        			<li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
        		</ul>
        	</div>
        	<div class="panel-body">
        		<form method="post" action="<?php echo e(route('pengguna.store')); ?>">
        			<?php echo csrf_field(); ?>

        			<div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
        				<label for="input1" class="form-label">Nama</label>
        				<input type="text" id="input1" name="nama" class="form-control" value="<?php echo e(old('nama')); ?>" required>
                        <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('nama')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                        <label for="input3" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required>
                        <?php if($errors->has('username')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('username')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('passwordname') ? ' has-error' : ''); ?>">
                        <label for="input7" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" required>
                        <?php if($errors->has('password')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('no_telp') ? ' has-error' : ''); ?>">
                        <label for="input4" class="form-label">Nomor Telpon</label>
                        <input type="text" id="input4" name="no_telp" class="form-control" value="<?php echo e(old('no_telp')); ?>" required>
                        <?php if($errors->has('no_telp')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('no_telp')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
                        <label for="input6" class="form-label">Alamat</label>
                        <input type="text" class="form-control" name="alamat" value="<?php echo e(old('alamat')); ?>" required>
                        <?php if($errors->has('alamat')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('alamat')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="select2" class="form-label">Sebagai</label>
                        <select class="selectpicker form-control" name="role" id="select2" required>
                            <option disable>-- Pilih Role --</option>
                            <option value="2">Order</option>
                            <option value="3">Kasir</option>
                            <option value="4">Produksi</option>
                            <option value="5">Owner</option>
                        </select>
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <a href="<?php echo e(URL(Helper::backButton())); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Kembali</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>