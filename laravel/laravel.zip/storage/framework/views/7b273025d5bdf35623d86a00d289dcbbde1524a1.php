<?php $__env->startSection('title', 'Data Costumer'); ?>
<?php $__env->startSection('content'); ?>
		<div class="row"> 
			<!-- Start Panel -->
			<div class="col-md-12">
				<?php if(Session::has('alert-success')): ?>
					<div class="foxlabel-alert foxlabel-alert-icon alert3"> <i class="fa fa-check"></i> <a href="#" class="closed">&times;</a> <?php echo e(\Illuminate\Support\Facades\Session::get('alert-success')); ?></div>
				<?php endif; ?>
				<div class="panel panel-default">
					<a href="<?php echo e(route('pelanggan.create')); ?>" class="btn btn-default"><i class="fa fa-plus-circle"></i>Tambah Data</a>
					<br>
					<br>
					<div class="panel-title"> Data Costumer </div>
					<div class="panel-body table-responsive">
						<table id="example0" class="table display">
							<thead>
								<tr>
									<th>No</th>
									<th>ID Member</th>
									<th>Nama</th>
									<th>Alamat</th>
									<th>No. Telp/HP</th>
									<th>Email</th>
									<th>Tipe Member</th>
									<th>Pesanan Outdoor</th>
									<th>Pesanan Indoor</th>
									<th>Pesanan Print A3</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<?php ($id_pelanggan = $datas->id); ?>
								<tr>
									<td><?php echo e($index + 1); ?></td>
									<td><?php echo e(sprintf("%06s", $datas->id)); ?></td>
									<td><?php echo e($datas->nama); ?></td>
									<td><?php echo e($datas->alamat); ?></td>
									<td><?php echo e($datas->no_telp); ?></td>
									<td><?php echo e($datas->email); ?></td>
									<td><?php echo e($datas->member->nm_tipe); ?></td>
									<td><?php echo e(Helper::totalOutdoor($id_pelanggan)); ?> kali</td>
									<td><?php echo e(Helper::totalIndoor($id_pelanggan)); ?> kali</td>
									<td><?php echo e(Helper::totalPrint($id_pelanggan)); ?> kali</td>
									<td>
										<form action="<?php echo e(route('pelanggan.destroy', $datas->id)); ?>" method="post">
											<?php echo e(csrf_field()); ?>

											<?php echo e(method_field('DELETE')); ?>

										<a href="<?php echo e(route('pelanggan.edit', $datas->id)); ?>" class="btn btn-option2"><i class="fa fa-info"></i>Edit</a>
										<button class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ?')"><i class="fa fa-check"></i>Delete</button>
										</form>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>
							</tbody>
							<tfoot>

							</tfoot>
						</table>
					</div>
				</div>
			</div>
			<!-- End Panel --> 
		</div>
		<!-- End Row --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>