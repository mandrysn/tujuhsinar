<?php $__env->startSection('title', 'Pembelian'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-padding animated fadeInRight"> 
		<div class="row"> 
			<!-- Start Panel -->
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-title"> Data Pembelian </div>
					<div class="panel-body table-responsive">
						<table id="example0" class="table display">
							<thead>
								<tr>
									<th>No.</th>
									<th>Order</th>
									<th>Pelanggan</th>
									<th>Tanggal Order</th>
									<th>Pembayaran</th>
								</tr>
							</thead>
							<tbody id="list_order">
								<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr id="order-<?php echo e($datas->id); ?>" class="listnya">
									<td><?php echo e($index + 1); ?></td>
									<td><?php echo e($datas->order); ?></td>
									<td><?php echo e($datas->pelanggan->nama); ?></td>
									<td><?php echo e(Helper::tanggalId($datas->tanggal)); ?></td>
									<td><?php echo e($datas->status_payment); ?></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>
							</tbody>
							<tfoot>
								
							</tfoot>
						</table>
					</div>
				</div>
			</div>
			<!-- End Panel --> 
		</div>
		<!-- End Row --> 
	</div>
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script> 
	<script type="text/javascript">
		
		
		setInterval(function() {
			console.log("test");
			jQuery.ajax({
					url: '<?php echo e(url("api/data_order")); ?>',
					type: 'GET',
					success:function(data){
						if(!jQuery(".listnya").length){
							jQuery("#list_order").html('');
						}
						jQuery.each(data, function(index, val) {
							if(!jQuery("#order-"+val.id).length){
								jQuery("#list_order").append('<tr id="order-'+val.id+'"><td>'+(index+1)+'</td><td>'+val.order+'</td><td>'+val.pelanggan.nama+'</td><td>'+val.tanggal_ord+'</td><td>'+val.status_payment+'</td></tr>')
							}
						});
					}
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
				});
			
		},5000);
		
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>