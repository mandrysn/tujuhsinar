<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelDashboard extends Model
{
    protected $table = 'printer';
}
